import requests
import xml.etree.ElementTree as ET

A=int(input("Enter your digit: "))
B=int(input("Enter your digit: "))

URL="http://www.dneonline.com/calculator.asmx"

JSON_body=f"""<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <Multiply xmlns="http://tempuri.org/">
      <intA>{A}</intA>
      <intB>{B}</intB>
    </Multiply>
  </soap:Body>
</soap:Envelope>"""

HEADER_value={"Content-Type":"text/xml"}

add_request=requests.post(url=URL,data=JSON_body,headers=HEADER_value)
response=ET.fromstring(add_request.text)

for i in response.iter("{http://tempuri.org/}MultiplyResult"):
        print(i.text)
