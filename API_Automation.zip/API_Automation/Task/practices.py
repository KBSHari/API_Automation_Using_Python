import requests

api=requests.get("https://api.github.com")
#print(api.text)
#print(api.content)
#print(api.json())
print(api.headers["Content-Type"])

api=requests.post("https://api.github.com")
#print(api.text)

api=requests.put("https://api.github.com")
#print(api.text)

api=requests.delete("https://reqres.in/api/users/2")
#print(api.status_code)

parameter={"user":"Hari","pass":"word"}
api=requests.get("https://api.github.com/get",params=parameter)
#print(api.url)



